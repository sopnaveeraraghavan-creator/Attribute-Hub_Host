# AttributeHub

> AI-powered product attribute management for eCommerce catalogues.

Built by **ecomneo**. Single-page React frontend + Express proxy backend.

## Quick Start

```bash
git clone <repo-url>
cd attributehub-app
cp .env.example .env        # add your OpenRouter key
npm run install:all
npm run dev
```

Open http://localhost:5173

---

## Tech Stack

| Layer | Choice |
|---|---|
| Frontend | React 18 + Vite |
| Styling | CSS custom properties (no framework) |
| Icons | Tabler Icons CDN |
| Excel I/O | SheetJS (xlsx) |
| AI | OpenRouter API (gpt-4o-mini / claude-3-haiku) |
| Backend | Express 4 (API proxy + CORS) |
| Storage | localStorage (client-side) |

---

## Folder Structure

```
attributehub-app/
├── frontend/               # React + Vite app
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   ├── pages/          # Page-level components
│   │   ├── hooks/          # Custom React hooks
│   │   ├── utils/          # Helpers (search, normalise, export)
│   │   └── data/           # Predefined category database
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── backend/                # Express proxy server
│   ├── src/
│   │   ├── routes/         # API routes
│   │   ├── middleware/      # Auth, rate-limit, CORS
│   │   └── utils/          # Helpers
│   ├── server.js
│   └── package.json
├── .env.example
└── package.json            # Root – runs both concurrently
```

---

## Environment Variables

Copy `.env.example` → `.env` and fill in:

```
OPENROUTER_API_KEY=sk-or-v1-...
VITE_API_BASE=http://localhost:3001
```

The backend proxies all AI calls so your key is never exposed to the browser.

---

## Scripts

| Command | Description |
|---|---|
| `npm run dev` | Start frontend (5173) + backend (3001) concurrently |
| `npm run build` | Build frontend for production |
| `npm run start` | Start production backend (serves built frontend) |
| `npm run install:all` | Install root + frontend + backend dependencies |

---

## Deployment

### Option A — Single VPS / Railway / Render

1. `npm run build` – outputs to `frontend/dist/`
2. Backend serves `frontend/dist` as static files in production
3. Set `NODE_ENV=production` and `OPENROUTER_API_KEY` in environment

### Option B — Vercel (frontend) + Railway (backend)

1. Deploy `frontend/` to Vercel; set `VITE_API_BASE` to your Railway URL
2. Deploy `backend/` to Railway; set `OPENROUTER_API_KEY`

### Option C — Docker

```bash
docker build -t attributehub .
docker run -p 3001:3001 -e OPENROUTER_API_KEY=sk-or-v1-... attributehub
```

---

## API Endpoints (Backend)

| Method | Path | Description |
|---|---|---|
| POST | `/api/ai/generate` | Generate attribute set for a category |
| POST | `/api/ai/refresh` | Refresh/improve existing attribute set |
| GET | `/api/health` | Health check |

All AI endpoints require `x-api-key` header OR server-side key via env.

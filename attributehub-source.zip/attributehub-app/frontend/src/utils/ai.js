/**
 * AttributeHub — AI client
 * Calls the backend proxy (preferred) or OpenRouter directly as fallback.
 */

const BASE = import.meta.env.VITE_API_BASE || '';

const MODELS = [
  'openai/gpt-4o-mini',
  'anthropic/claude-3-haiku',
  'anthropic/claude-3.5-haiku',
  'google/gemini-1.5-flash',
  'mistralai/mistral-7b-instruct',
];

const ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';

// ── Parse attribute JSON from AI response text ────────────────────
export function parseAttrsFromText(text) {
  let clean = text
    .replace(/```json[\s\S]*?```/gi, m => m.replace(/```json/i, '').replace(/```/g, ''))
    .replace(/```[\s\S]*?```/g, m => m.replace(/```/g, ''))
    .trim();
  const start = clean.indexOf('[');
  const end   = clean.lastIndexOf(']');
  if (start === -1 || end === -1) throw new Error('No JSON array in AI response');
  return JSON.parse(clean.slice(start, end + 1));
}

// ── Call via backend proxy ────────────────────────────────────────
async function callBackend(endpoint, body) {
  const res  = await fetch(`${BASE}/api/ai/${endpoint}`, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body:    JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || `Backend error ${res.status}`);
  return data;
}

// ── Call OpenRouter directly (browser fallback) ───────────────────
async function callOpenRouterDirect(prompt, apiKey) {
  let lastErr = '';
  for (const model of MODELS) {
    const res = await fetch(ENDPOINT, {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'HTTP-Referer':  'https://attributehub.ecomneo.com',
        'X-Title':       'AttributeHub',
      },
      body: JSON.stringify({ model, max_tokens: 2000, messages: [{ role: 'user', content: prompt }] }),
    });
    const data = await res.json();
    if (res.ok) {
      const text  = data.choices?.[0]?.message?.content || '';
      const attrs = parseAttrsFromText(text);
      return { attributes: attrs, model };
    }
    lastErr = data?.error?.message || `HTTP ${res.status}`;
    const isModelErr = lastErr.toLowerCase().includes('endpoint')
      || lastErr.toLowerCase().includes('no endpoints')
      || lastErr.toLowerCase().includes('not found');
    if (!isModelErr) break;
  }
  throw new Error(lastErr || 'All models failed');
}

// ── Public API ────────────────────────────────────────────────────
export async function generateAttributes(categoryName, apiKey) {
  try {
    return await callBackend('generate', { categoryName });
  } catch (backendErr) {
    console.warn('Backend unavailable, falling back to direct:', backendErr.message);
    if (!apiKey) throw new Error('No API key — set OPENROUTER_API_KEY on the server or paste your key in the top bar.');
    const prompt = buildGeneratePrompt(categoryName);
    return callOpenRouterDirect(prompt, apiKey);
  }
}

export async function refreshAttributes(categoryName, existingAttributes, apiKey) {
  try {
    return await callBackend('refresh', { categoryName, existingAttributes });
  } catch (backendErr) {
    console.warn('Backend unavailable, falling back to direct:', backendErr.message);
    if (!apiKey) throw new Error('No API key available.');
    const prompt = buildRefreshPrompt(categoryName, existingAttributes);
    return callOpenRouterDirect(prompt, apiKey);
  }
}

// ── Inline prompt builders (used for direct fallback) ─────────────
function buildGeneratePrompt(categoryName) {
  return `Return ONLY a valid JSON array. No markdown. No explanation. Start with [ and end with ].

Category: "${categoryName}"
Generate 10-14 product attributes SPECIFIC and RELEVANT to the "${categoryName}" category.
Do NOT include generic attributes unless genuinely critical.
Focus on physical specs, performance characteristics, and buyer-decision attributes.

Each attribute: {"name":"","requirement":"Mandatory|Recommended|Optional","possibleValues":[],"unit":"","type":"text|single_select|multi_select|number","dataType":"LOV|Numeric|Integer|Text","attributeType":"Product|Variant|Item","uom":"","multiSelect":"Y|N","isFrontendNode":"Y|N","isDependent":"Y|N","dependentOn":"","competitorCoverage":0,"gs1Required":false,"trendSignal":"stable","rationale":""}`;
}

function buildRefreshPrompt(categoryName, existingAttributes) {
  const names = existingAttributes.map(a => a.name || '').filter(Boolean).join(', ');
  return `Return ONLY a valid JSON array. No markdown. No explanation. Start with [ and end with ].

Category: "${categoryName}"
Existing: ${names || 'none'}
Refresh and improve. Keep strongest, remove generic, add missing high-value attributes.
Target 12-15 total. Same JSON schema as generate.`;
}

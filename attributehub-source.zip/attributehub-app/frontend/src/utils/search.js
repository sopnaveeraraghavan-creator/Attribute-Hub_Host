/**
 * AttributeHub — Search & normalisation utilities
 * Mirrors the algorithm from the original single-file build.
 */
import PREDEFINED from '../data/predefined.js';

// ── Normalise attribute shape ─────────────────────────────────────
export function norm(a) {
  return {
    name:            a.name        || a.n   || '',
    requirement:     a.requirement || a.req || 'Recommended',
    possibleValues:  a.possibleValues || a.pv || [],
    unit:            a.unit  || a.uom || '',
    type:            a.type  || 'text',
    source:          a.source || [],
    isFilterable:    a.isFilterable ?? (a.isFrontendNode === 'Y'),
    dataType:        a.dataType || a.dt || 'LOV',
    attributeType:   a.attributeType || a.at || 'Product',
    uom:             a.uom   || a.unit || '',
    multiSelect:     a.multiSelect || a.ms || 'N',
    isFrontendNode:  a.isFrontendNode || a.fn || 'N',
    isDependent:     a.isDependent   || a.dep || 'N',
    dependentOn:     a.dependentOn   || a.depOn || '',
    rationale:       a.rationale     || '',
    competitorCoverage: a.competitorCoverage ?? a.cov ?? 0,
    gs1Required:     a.gs1Required   ?? a.gs1 ?? false,
    trendSignal:     a.trendSignal   || a.trend || 'stable',
  };
}

// ── Text normalise ────────────────────────────────────────────────
function normalizeText(t) {
  return t.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}

// ── Query expansion (common product synonyms) ─────────────────────
const SYNONYMS = {
  tv: 'television', tvs: 'televisions',
  ac: 'air conditioner', acs: 'air conditioners',
  fridge: 'refrigerator', fridges: 'refrigerators',
  washer: 'washing machine',
  laptop: 'laptop computer',
  phone: 'smartphone', phones: 'smartphones',
  cam: 'camera',
};

function expandQuery(q) {
  const parts = normalizeText(q).split(' ');
  return parts.map(p => SYNONYMS[p] || p).join(' ');
}

// ── Levenshtein distance ──────────────────────────────────────────
function levenshtein(a, b) {
  const m = a.length, n = b.length;
  const dp = Array.from({ length: m + 1 }, (_, i) =>
    Array.from({ length: n + 1 }, (_, j) => (i === 0 ? j : j === 0 ? i : 0))
  );
  for (let i = 1; i <= m; i++)
    for (let j = 1; j <= n; j++)
      dp[i][j] = a[i - 1] === b[j - 1]
        ? dp[i - 1][j - 1]
        : 1 + Math.min(dp[i - 1][j], dp[i][j - 1], dp[i - 1][j - 1]);
  return dp[m][n];
}

// ── Fuzzy score ───────────────────────────────────────────────────
function fuzzy(query, target) {
  const q = expandQuery(query);
  const t = normalizeText(target);
  if (t === q) return 1;
  if (t.startsWith(q) || q.startsWith(t)) return 0.95;
  if (t.includes(q) || q.includes(t)) return 0.85;
  // word overlap
  const qw = new Set(q.split(' '));
  const tw = t.split(' ');
  const overlap = tw.filter(w => qw.has(w)).length;
  if (overlap > 0) return 0.6 + (overlap / Math.max(qw.size, tw.length)) * 0.25;
  // edit distance on short queries
  if (q.length <= 12) {
    const dist = levenshtein(q, t);
    const maxLen = Math.max(q.length, t.length);
    const sim = 1 - dist / maxLen;
    if (sim >= 0.6) return sim * 0.7;
  }
  return 0;
}

// ── Search all sets ───────────────────────────────────────────────
export function allSets(customSets = []) {
  return [...PREDEFINED, ...customSets];
}

export function searchSets(query, customSets = []) {
  if (!query.trim()) return [];
  const fields = ['categoryName', 'className', 'l1', 'l2', 'l3', 'l4', 'metaCategory', 'description'];
  return allSets(customSets)
    .map(set => {
      const score = Math.max(...fields.map(f => fuzzy(query, set[f] || '')));
      return { set, score };
    })
    .filter(({ score }) => score >= 0.4)
    .sort((a, b) => b.score - a.score)
    .map(({ set }) => set);
}

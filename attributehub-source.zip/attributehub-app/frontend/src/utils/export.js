/**
 * AttributeHub — Export utilities
 * CSV and Excel (SheetJS) export for attribute sets.
 */
import * as XLSX from 'xlsx';

export const EXPORT_HEADERS = [
  'Category', 'Attribute Name', 'Requirement', 'Data Type', 'Attribute Type',
  'Type', 'Possible Values', 'UOM', 'Multi Select', 'Frontend Node',
  'Is Dependent', 'Dependent On', 'Rationale',
];

function attrRow(categoryName, a) {
  return [
    categoryName,
    a.name,
    a.requirement || a.req || '',
    a.dataType    || a.dt  || '',
    a.attributeType || a.at || '',
    a.type || '',
    (a.possibleValues || a.pv || []).join(' | '),
    a.uom  || a.unit || '',
    a.multiSelect    || a.ms  || 'N',
    a.isFrontendNode || a.fn  || 'N',
    a.isDependent    || a.dep || 'N',
    a.dependentOn    || a.depOn || '',
    a.rationale || '',
  ];
}

// ── CSV export ────────────────────────────────────────────────────
export function exportCSV(sets, filename = 'attribute_sets.csv') {
  const esc  = v => '"' + String(v).replace(/"/g, '""') + '"';
  const rows = [EXPORT_HEADERS.map(esc).join(',')];
  sets.forEach(set => {
    (set.attributes || []).forEach(a => {
      rows.push(attrRow(set.categoryName, a).map(esc).join(','));
    });
  });
  const blob = new Blob([rows.join('\n')], { type: 'text/csv' });
  triggerDownload(blob, filename);
}

// ── XLSX export ───────────────────────────────────────────────────
export function exportXLSX(sets, filename = 'attribute_sets.xlsx') {
  const wb = XLSX.utils.book_new();

  // Sheet 1 — all categories combined
  const allRows = [EXPORT_HEADERS];
  sets.forEach(set => {
    (set.attributes || []).forEach(a => allRows.push(attrRow(set.categoryName, a)));
  });
  const wsCombined = XLSX.utils.aoa_to_sheet(allRows);
  wsCombined['!cols'] = [
    { wch: 28 }, { wch: 28 }, { wch: 14 }, { wch: 14 }, { wch: 16 },
    { wch: 14 }, { wch: 30 }, { wch: 8  }, { wch: 12 }, { wch: 14 },
    { wch: 13 }, { wch: 14 }, { wch: 50 },
  ];
  XLSX.utils.book_append_sheet(wb, wsCombined, 'All Attribute Sets');

  // One sheet per category
  sets.forEach(set => {
    const catHeaders = EXPORT_HEADERS.slice(1); // omit 'Category' column
    const catRows    = [catHeaders, ...(set.attributes || []).map(a => attrRow(set.categoryName, a).slice(1))];
    const ws         = XLSX.utils.aoa_to_sheet(catRows);
    ws['!cols']      = catHeaders.map((_, i) => ({ wch: i === catHeaders.length - 1 ? 50 : 16 }));
    const sheetName  = set.categoryName.replace(/[\\/:?*[\]]/g, '_').slice(0, 31);
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
  });

  XLSX.writeFile(wb, filename);
}

// ── Single attribute set export (from view page) ──────────────────
export function exportSetCSV(set) {
  exportCSV([set], `${set.categoryName}_attributes.csv`);
}

export function exportSetXLSX(set) {
  exportXLSX([set], `${set.categoryName}_attributes.xlsx`);
}

// ── Helper ────────────────────────────────────────────────────────
function triggerDownload(blob, filename) {
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  URL.revokeObjectURL(a.href);
}

import { useState, useRef } from 'react';
import BatchHistory from '../components/BatchHistory.jsx';
import BulkResults from '../components/BulkResults.jsx';
import { useBulkUpload } from '../hooks/useBulkUpload.js';
import { searchSets } from '../utils/search.js';
import { TEMPLATE_B64 } from '../data/template.js';

export default function Dashboard({ customSets, apiKey, onOpenSet, onGoCreate, stats }) {
  const [searchQ, setSearchQ]   = useState('');
  const [searchRes, setSearchRes] = useState(null);
  const [activeTab, setActiveTab] = useState('single'); // 'single' | 'bulk' | 'browse'
  const fileRef = useRef();

  const {
    rows, history, processing,
    processFile, generateRow, retainRow,
    deleteBatchHistory, restoreBatch,
  } = useBulkUpload(customSets, apiKey);

  function handleSearch() {
    if (!searchQ.trim()) return;
    const results = searchSets(searchQ, customSets);
    setSearchRes(results);
  }

  function downloadTemplate() {
    const byteStr = atob(TEMPLATE_B64);
    const ab = new ArrayBuffer(byteStr.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteStr.length; i++) ia[i] = byteStr.charCodeAt(i);
    const blob = new Blob([ab], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'Bulk_Upload_Template.xlsx';
    a.click();
  }

  return (
    <div className="page" id="pageDashboard">
      {/* Stats */}
      <div className="stats">
        <div className="stat">
          <div className="stat-val">{stats.total}</div>
          <div className="stat-lbl"><i className="ti ti-database" /> Total Categories</div>
        </div>
        <div className="stat">
          <div className="stat-val">{stats.custom}</div>
          <div className="stat-lbl"><i className="ti ti-layers" /> Custom Sets</div>
        </div>
        <div className="stat">
          <div className="stat-val">{stats.batches}</div>
          <div className="stat-lbl"><i className="ti ti-history" /> Batches Run</div>
        </div>
      </div>

      {/* Tabs */}
      <div className="tabs">
        {['single', 'bulk', 'browse'].map(tab => (
          <button key={tab} className={`tab-btn ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
            {tab === 'single' && <><i className="ti ti-search" /> Single Search</>}
            {tab === 'bulk'   && <><i className="ti ti-upload" /> Bulk Upload</>}
            {tab === 'browse' && <><i className="ti ti-folder" /> Browse DB</>}
          </button>
        ))}
      </div>

      {/* Single Search */}
      {activeTab === 'single' && (
        <div className="tab-panel">
          <div className="search-wrap">
            <input
              className="search-input"
              placeholder="Search category (e.g. Microwaves, Running Shoes…)"
              value={searchQ}
              onChange={e => setSearchQ(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
            />
            <button className="search-btn btn btn-primary" onClick={handleSearch}>
              <i className="ti ti-search" /> Search
            </button>
          </div>

          {searchRes !== null && (
            searchRes.length === 0
              ? (
                <div style={{ textAlign: 'center', padding: '32px 0' }}>
                  <p style={{ color: 'var(--text2)', marginBottom: 12 }}>No match for "<strong>{searchQ}</strong>"</p>
                  <button className="btn btn-primary" onClick={() => onGoCreate(searchQ)}>
                    <i className="ti ti-sparkles" /> Generate with AI
                  </button>
                </div>
              )
              : (
                <div>
                  {searchRes.map((set, i) => (
                    <div key={set.id || i} className="cat-item" onClick={() => onOpenSet(set)} style={{ cursor: 'pointer' }}>
                      <div className="cat-left">
                        <div style={{ fontWeight: 700 }}>{set.categoryName}</div>
                        <div style={{ fontSize: 11, color: 'var(--text2)' }}>{set.description}</div>
                      </div>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <span className="badge b-exist" style={{ fontSize: 10 }}>{set.attributes?.length || 0} attrs</span>
                        <i className="ti ti-arrow-right" style={{ color: 'var(--text3)' }} />
                      </div>
                    </div>
                  ))}
                </div>
              )
          )}
        </div>
      )}

      {/* Bulk Upload */}
      {activeTab === 'bulk' && (
        <div className="tab-panel">
          <div style={{ display: 'flex', gap: 10, marginBottom: 16, alignItems: 'center', flexWrap: 'wrap' }}>
            <button className="btn btn-sm" onClick={downloadTemplate}>
              <i className="ti ti-download" /> Download Template
            </button>
            <button className="btn btn-primary btn-sm" onClick={() => fileRef.current?.click()} disabled={processing}>
              <i className="ti ti-upload" /> {processing ? 'Processing…' : 'Upload File'}
            </button>
            <input
              ref={fileRef}
              type="file"
              accept=".csv,.txt,.tsv,.xlsx"
              style={{ display: 'none' }}
              onChange={e => { const f = e.target.files[0]; if (f) { processFile(f); e.target.value = ''; } }}
            />
            <span style={{ fontSize: 11, color: 'var(--text3)' }}>Accepts .xlsx, .csv, .tsv, .txt</span>
          </div>

          <BatchHistory history={history} onView={restoreBatch} onDelete={deleteBatchHistory} />

          {rows.length > 0 && (
            <BulkResults rows={rows} onGenerate={generateRow} onRetain={retainRow} />
          )}
        </div>
      )}

      {/* Browse (placeholder — full browse UI lives in original; expandable here) */}
      {activeTab === 'browse' && (
        <div className="tab-panel">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: 12 }}>
            {[...Array.from(new Set([...(customSets || []), ...[]].map(s => s.metaCategory))).values()].length === 0 && (
              <p style={{ color: 'var(--text3)', fontStyle: 'italic' }}>No categories yet. Use Single Search or Bulk Upload to add some.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

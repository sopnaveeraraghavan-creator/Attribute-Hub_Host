import { useState } from 'react';
import { exportCSV, exportXLSX } from '../utils/export.js';

export default function BulkResults({ rows, onGenerate, onRetain }) {
  const [open, setOpen] = useState(true);

  const newRows = rows.filter(r => (r.status === 'new' || r.status === 'refreshed') && r.generatedSet);

  const SMAP = {
    pending:    ['b-opt',     'Pending'],
    existing:   ['b-exist',   'Existing'],
    new:        ['b-warn',    'New'],
    refreshed:  ['b-refresh', 'Refreshed'],
    retained:   ['b-retain',  'Retained'],
    generating: ['b-info',    'Generating…'],
  };

  return (
    <div id="bulkResultsSection">
      {/* Header */}
      <div className="sec-head" style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <span
          style={{ cursor: 'pointer', userSelect: 'none', display: 'flex', alignItems: 'center', gap: 8 }}
          onClick={() => setOpen(o => !o)}
        >
          <i className="ti ti-list-check" /> Audit Results
          <i
            className={`ti ti-chevron-${open ? 'up' : 'down'}`}
            style={{ fontSize: 14, color: 'var(--text3)', transition: 'transform .18s' }}
          />
        </span>

        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {newRows.length > 0 && (
            <>
              <span style={{ fontSize: 11, color: 'var(--text3)' }}>
                {newRows.length} new attribute set{newRows.length > 1 ? 's' : ''}
              </span>
              <button className="btn btn-sm" onClick={() => exportCSV(newRows.map(r => r.generatedSet), 'new_attribute_sets.csv')}>
                <i className="ti ti-file-text" /> Export New (CSV)
              </button>
              <button className="btn btn-sm btn-primary" onClick={() => exportXLSX(newRows.map(r => r.generatedSet), 'new_attribute_sets.xlsx')}>
                <i className="ti ti-file-spreadsheet" /> Export New (Excel)
              </button>
            </>
          )}
        </div>
      </div>

      {/* Table */}
      {open && (
        <div className="tbl-wrap glass">
          <table className="mtable">
            <thead>
              <tr>
                <th>#</th>
                <th>Class Name</th>
                <th>Matched in DB</th>
                <th>Attr Count</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row, idx) => {
                const [bc, bl] = SMAP[row.status] || ['b-opt', 'Pending'];
                const canView  = !!(row.matchedSet || row.generatedSet);
                return (
                  <tr key={row.id}>
                    <td style={{ color: 'var(--text3)' }}>{idx + 1}</td>
                    <td style={{ fontWeight: 700 }}>{row.inputName}</td>
                    <td style={{ color: 'var(--text2)' }}>
                      {row.matchedSet
                        ? <>{row.matchedSet.categoryName} <span style={{ fontSize: 10 }}>· v{row.matchedSet.version}</span></>
                        : <span style={{ fontStyle: 'italic', fontSize: 11 }}>No match</span>
                      }
                    </td>
                    <td style={{ textAlign: 'center' }}>{row.attributeCount || '—'}</td>
                    <td><span className={`badge ${bc}`} style={{ fontSize: 10 }}>{bl}</span></td>
                    <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                      {canView && (
                        <button className="btn btn-xs" style={{ marginLeft: 3 }}>
                          <i className="ti ti-eye" /> View
                        </button>
                      )}
                      {(row.status === 'existing' || row.status === 'retained' || row.status === 'refreshed') && row.matchedSet && (
                        <>
                          <button className="btn btn-xs" onClick={() => onRetain(idx)} disabled={row.status === 'retained'} style={{ marginLeft: 3 }}>
                            <i className="ti ti-check" /> Retain
                          </button>
                          <button className="btn btn-xs" onClick={() => onGenerate(idx, 'refresh')} style={{ marginLeft: 3 }}>
                            <i className="ti ti-refresh" /> Refresh
                          </button>
                        </>
                      )}
                      {row.status === 'generating' && (
                        <span style={{ fontSize: 11, color: 'var(--text3)' }}>
                          <i className="ti ti-loader-2 spinning" /> Generating…
                        </span>
                      )}
                      {row.status === 'new' && !row.generatedSet && (
                        <button className="btn btn-xs btn-primary" onClick={() => onGenerate(idx, 'create')} style={{ marginLeft: 3 }}>
                          <i className="ti ti-plus" /> Create
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

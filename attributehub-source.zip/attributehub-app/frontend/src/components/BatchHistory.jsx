import { useState } from 'react';

export default function BatchHistory({ history, onView, onDelete }) {
  const [open, setOpen] = useState(false);
  if (!history.length) return null;

  return (
    <div id="batchHistSection" style={{ marginBottom: 16 }}>
      <div
        className="sec-head"
        style={{ cursor: 'pointer', userSelect: 'none', display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}
        onClick={() => setOpen(o => !o)}
      >
        <span>
          <i className="ti ti-history" /> Batch History
        </span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <span style={{ fontSize: 11, color: 'var(--text3)', fontWeight: 600 }}>
            {history.length} batch{history.length > 1 ? 'es' : ''}
          </span>
          <i
            className="ti ti-chevron-down"
            style={{ fontSize: 15, color: 'var(--text3)', transition: 'transform .18s', transform: open ? 'rotate(180deg)' : '' }}
          />
        </span>
      </div>

      {open && (
        <div className="tbl-wrap glass" style={{ marginBottom: 14 }}>
          <table className="mtable">
            <thead>
              <tr>
                <th>File Name</th>
                <th>Uploaded</th>
                <th>Categories</th>
                <th>Existing</th>
                <th>New</th>
                <th>Size</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {history.map((b, bi) => (
                <tr key={b.id} style={{ background: b.active ? 'var(--orange-bg)' : '' }}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <i className="ti ti-file-spreadsheet" style={{ fontSize: 13, color: 'var(--orange-d)' }} />
                      <span style={{ fontWeight: 700 }}>{b.fileName}</span>
                    </div>
                  </td>
                  <td style={{ color: 'var(--text2)', fontSize: 11 }}>{b.uploadedAt}</td>
                  <td style={{ textAlign: 'center', fontWeight: 700 }}>{b.categoryCount}</td>
                  <td style={{ textAlign: 'center' }}><span className="badge b-exist" style={{ fontSize: 10 }}>{b.existingCount}</span></td>
                  <td style={{ textAlign: 'center' }}><span className="badge b-warn" style={{ fontSize: 10 }}>{b.newCount}</span></td>
                  <td style={{ textAlign: 'center', color: 'var(--text2)', fontSize: 11 }}>{b.sizeKb} KB</td>
                  <td style={{ textAlign: 'center' }}>
                    <span className={`badge ${b.active ? 'b-active' : 'b-opt'}`} style={{ fontSize: 10 }}>
                      {b.active ? 'Active' : 'Processed'}
                    </span>
                  </td>
                  <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                    {b.active && (
                      <button className="btn btn-xs btn-primary" onClick={() => onView(bi)} style={{ marginLeft: 3 }}>
                        <i className="ti ti-eye" /> View
                      </button>
                    )}
                    <button className="btn btn-xs" onClick={() => onDelete(bi)} style={{ marginLeft: 3, color: 'var(--red)' }}>
                      <i className="ti ti-trash" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

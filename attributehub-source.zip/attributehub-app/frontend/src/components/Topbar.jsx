import { useState } from 'react';

export default function Topbar({ apiKey, onApiKeyChange, onBack, showBack }) {
  const [show, setShow] = useState(false);
  const isValid = apiKey.startsWith('sk-or-') || apiKey.startsWith('sk-ant-');

  return (
    <div className="topbar">
      <div className="logo">
        <div className="logo-mark"><i className="ti ti-layers-subtract" /></div>
        <div>
          <div className="logo-name">AttributeHub</div>
          <div style={{ fontSize: 10, color: 'var(--text3)' }}>by ecomneo</div>
        </div>
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        {showBack && (
          <button className="btn btn-sm" onClick={onBack}>
            <i className="ti ti-arrow-left" /> Dashboard
          </button>
        )}

        <div id="apiKeyWrap" style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <div style={{ position: 'relative' }}>
            <input
              type={show ? 'text' : 'password'}
              placeholder="Paste OpenRouter key…"
              value={apiKey}
              onChange={e => onApiKeyChange(e.target.value)}
              style={{
                padding: '6px 32px 6px 10px',
                borderRadius: 7,
                border: `1.5px solid ${apiKey && !isValid ? 'var(--amber)' : isValid ? 'var(--green)' : 'var(--border2)'}`,
                fontSize: 12,
                width: 220,
                background: 'var(--card)',
                color: 'var(--text)',
                outline: 'none',
              }}
            />
            <button
              onClick={() => setShow(s => !s)}
              style={{ position: 'absolute', right: 6, top: '50%', transform: 'translateY(-50%)', background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text3)', padding: 0 }}
            >
              <i className={`ti ti-${show ? 'eye-off' : 'eye'}`} style={{ fontSize: 14 }} />
            </button>
          </div>
          {apiKey && (
            <span style={{ fontSize: 11, color: isValid ? 'var(--green)' : 'var(--amber)', fontWeight: 600 }}>
              {isValid ? '✓ Key set' : '⚠ Unrecognised format'}
            </span>
          )}
        </div>
      </div>
    </div>
  );
}

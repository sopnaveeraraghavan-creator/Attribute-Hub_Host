/**
 * AttributeTable — renders a list of attributes in the standard table format.
 * Used on View, Create, and Bulk modal pages.
 */
export default function AttributeTable({ attributes, onDelete, onEdit, showActions = true }) {
  if (!attributes?.length) {
    return <p style={{ color: 'var(--text3)', fontStyle: 'italic', padding: '12px 0' }}>No attributes.</p>;
  }

  function reqBadge(req) {
    const r = (req || '').toLowerCase();
    if (r === 'mandatory') return <span className="badge b-man">Mandatory</span>;
    if (r === 'recommended') return <span className="badge b-rec">Recommended</span>;
    return <span className="badge b-opt">{req || 'Optional'}</span>;
  }

  function pvChips(vals) {
    if (!vals?.length) return <span style={{ color: 'var(--text3)', fontSize: 11 }}>—</span>;
    return (
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3 }}>
        {vals.slice(0, 5).map((v, i) => (
          <span key={i} className="pv-chip">{v}</span>
        ))}
        {vals.length > 5 && <span className="pv-chip">+{vals.length - 5}</span>}
      </div>
    );
  }

  function yn(v) {
    return <span className={`yn ${v === 'Y' ? 'yn-y' : 'yn-n'}`}>{v === 'Y' ? 'Y' : 'N'}</span>;
  }

  return (
    <div className="tbl-wrap">
      <table className="mtable">
        <thead>
          <tr>
            <th>Attribute Name</th>
            <th>Requirement</th>
            <th>Data Type</th>
            <th>Attr Type</th>
            <th>Possible Values</th>
            <th>UOM</th>
            <th>Multi</th>
            <th>Frontend</th>
            <th>Dependent</th>
            {showActions && <th style={{ textAlign: 'right' }}>Actions</th>}
          </tr>
        </thead>
        <tbody>
          {attributes.map((a, i) => (
            <tr key={i}>
              <td style={{ fontWeight: 700 }}>{a.name}</td>
              <td>{reqBadge(a.requirement || a.req)}</td>
              <td><span className="type-mono">{a.dataType || a.dt || '—'}</span></td>
              <td>
                <span className={`badge ${(a.attributeType || a.at) === 'Variant' ? 'b-purple' : 'b-info'}`} style={{ fontSize: 10 }}>
                  {a.attributeType || a.at || '—'}
                </span>
              </td>
              <td>{pvChips(a.possibleValues || a.pv)}</td>
              <td style={{ color: 'var(--text2)', fontSize: 11 }}>{a.uom || a.unit || '—'}</td>
              <td>{yn(a.multiSelect || a.ms)}</td>
              <td>{yn(a.isFrontendNode || a.fn)}</td>
              <td>{yn(a.isDependent || a.dep)}</td>
              {showActions && (
                <td style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>
                  {onEdit && (
                    <button className="btn btn-xs" onClick={() => onEdit(i)} style={{ marginLeft: 4 }}>
                      <i className="ti ti-pencil" />
                    </button>
                  )}
                  {onDelete && (
                    <button className="btn btn-xs" onClick={() => onDelete(i)} style={{ marginLeft: 4, color: 'var(--red)' }}>
                      <i className="ti ti-trash" />
                    </button>
                  )}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/**
 * useApiKey — persists OpenRouter API key in sessionStorage
 */
import { useState, useCallback } from 'react';

const STORAGE_KEY = 'ah_api_key';

function mask(key) {
  if (!key || key.length < 12) return key;
  return key.slice(0, 8) + '••••••••' + key.slice(-4);
}

export function useApiKey() {
  const [key, setKeyState] = useState(() => {
    try { return sessionStorage.getItem(STORAGE_KEY) || ''; } catch { return ''; }
  });

  const setKey = useCallback((val) => {
    setKeyState(val);
    try { sessionStorage.setItem(STORAGE_KEY, val); } catch {}
  }, []);

  const isValid = key.startsWith('sk-or-') || key.startsWith('sk-ant-');
  const status  = !key ? '' : isValid ? '✓ Key set' : '⚠ Unrecognised format';

  return { key, setKey, isValid, status, masked: mask(key) };
}

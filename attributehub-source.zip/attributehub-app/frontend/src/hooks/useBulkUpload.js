/**
 * useBulkUpload — handles file parsing, row state, and batch history
 */
import { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { searchSets } from '../utils/search.js';
import { norm } from '../utils/search.js';
import { generateAttributes, refreshAttributes } from '../utils/ai.js';

function delay(ms) { return new Promise(r => setTimeout(r, ms)); }

export function useBulkUpload(customSets, apiKey) {
  const [rows,    setRows]    = useState([]);
  const [history, setHistory] = useState(() => {
    try { return JSON.parse(localStorage.getItem('ah_batchHistory') || '[]'); } catch { return []; }
  });
  const [processing, setProcessing] = useState(false);

  const saveHistory = useCallback((h) => {
    setHistory(h);
    try { localStorage.setItem('ah_batchHistory', JSON.stringify(h)); } catch {}
  }, []);

  // ── Parse file ────────────────────────────────────────────────
  const processFile = useCallback(async (file) => {
    setProcessing(true);
    let cats = [];

    const isXLSX = /\.xlsx?$/i.test(file.name);
    if (isXLSX) {
      const buf  = await file.arrayBuffer();
      const wb   = XLSX.read(buf, { type: 'array' });
      const ws   = wb.Sheets[wb.SheetNames[0]];
      const raw  = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
      if (!raw.length) { setProcessing(false); return; }
      const hdr  = (raw[0] || []).map(c => String(c).toLowerCase().trim());
      const isNew = hdr.some(c => c.includes('unique id') || c.includes('category/product type'));
      const isOld = hdr.some(c => c.includes('class name'));
      const seen  = new Set();
      if (isNew) {
        raw.slice(1).forEach(r => { const n = String(r[1]||'').trim(); if (n && !seen.has(n)) { seen.add(n); cats.push(n); } });
      } else if (isOld) {
        raw.slice(1).forEach(r => { const n = String(r[1]||'').trim(); if (n && !seen.has(n)) { seen.add(n); cats.push(n); } });
      } else {
        const start = hdr[0].includes('category') || hdr[0].includes('name') ? 1 : 0;
        raw.slice(start).forEach(r => { const n = String(r[0]||'').trim(); if (n && !seen.has(n)) { seen.add(n); cats.push(n); } });
      }
    } else {
      const text = await file.text();
      const sep  = /\.tsv$/i.test(file.name) ? '\t' : ',';
      const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
      const hdr   = (lines[0] || '').toLowerCase();
      const isNew = hdr.includes('unique id') || hdr.includes('category/product type');
      const isOld = hdr.includes('class name');
      const seen  = new Set();
      if (isNew || isOld) {
        lines.slice(1).forEach(l => { const cols = l.split(sep).map(c => c.replace(/^"|"$/g,'').trim()); const n = cols[1]; if (n && !seen.has(n)) { seen.add(n); cats.push(n); } });
      } else {
        const data = hdr.includes('category') || hdr.includes('name') ? lines.slice(1) : lines;
        cats = data.map(l => l.split(sep)[0].replace(/^"|"$/g,'').trim()).filter(Boolean);
      }
    }

    // Build rows
    const newRows = [];
    for (let i = 0; i < cats.length; i++) {
      await delay(100);
      const name    = cats[i];
      const matched = searchSets(name, customSets)[0] || null;
      newRows.push({
        id: `${i}-${name}`, inputName: name,
        status: matched ? 'existing' : 'new',
        matchedSet: matched, generatedSet: null,
        attributeCount: matched?.attributes?.length || null,
      });
    }
    setRows(newRows);

    // Save to history
    const entry = {
      id: `batch-${Date.now()}`,
      fileName: file.name,
      uploadedAt: new Date().toLocaleString(),
      categoryCount: newRows.length,
      existingCount: newRows.filter(r => r.status === 'existing').length,
      newCount: newRows.filter(r => r.status === 'new').length,
      sizeKb: Math.max(1, Math.round(file.size / 1024)),
      active: true,
      rows: newRows,
    };
    saveHistory([entry, ...history.map(h => ({ ...h, active: false }))]);
    setProcessing(false);
  }, [customSets, history, saveHistory]);

  // ── AI generate for a row ─────────────────────────────────────
  const generateRow = useCallback(async (idx, action) => {
    const row = rows[idx];
    setRows(prev => prev.map((r, i) => i === idx ? { ...r, status: 'generating' } : r));
    try {
      const result = action === 'refresh'
        ? await refreshAttributes(row.inputName, row.matchedSet?.attributes || [], apiKey)
        : await generateAttributes(row.inputName, apiKey);
      const attrs = (result.attributes || []).map(norm);
      const gen = {
        id: `gen-${Date.now()}`,
        categoryName: row.inputName,
        metaCategory: row.matchedSet?.metaCategory || 'New Category',
        description: `AI-generated attribute set for ${row.inputName}`,
        attributes: attrs,
        lastUpdated: new Date().toISOString().slice(0, 10),
        version: '1.0',
      };
      setRows(prev => prev.map((r, i) => i === idx
        ? { ...r, status: action === 'refresh' ? 'refreshed' : 'new', generatedSet: gen, attributeCount: attrs.length }
        : r
      ));
    } catch (err) {
      alert(`AI generation failed for "${row.inputName}": ${err.message}`);
      setRows(prev => prev.map((r, i) => i === idx ? { ...r, status: row.status } : r));
    }
  }, [rows, apiKey]);

  const retainRow = useCallback((idx) => {
    setRows(prev => prev.map((r, i) => i === idx ? { ...r, status: 'retained' } : r));
  }, []);

  const deleteBatchHistory = useCallback((bi) => {
    if (!confirm('Remove this batch from history?')) return;
    const next = history.filter((_, i) => i !== bi);
    saveHistory(next);
  }, [history, saveHistory]);

  const restoreBatch = useCallback((bi) => {
    const b = history[bi];
    if (!b?.rows?.length) { alert('No row data saved for this batch.'); return; }
    setRows(b.rows);
  }, [history]);

  return {
    rows, setRows, history,
    processing, processFile,
    generateRow, retainRow,
    deleteBatchHistory, restoreBatch,
  };
}

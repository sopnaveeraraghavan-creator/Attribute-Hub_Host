import { useState, useEffect } from 'react';
import Topbar from './components/Topbar.jsx';
import Dashboard from './pages/Dashboard.jsx';
import AttributeTable from './components/AttributeTable.jsx';
import { allSets } from './utils/search.js';
import { generateAttributes } from './utils/ai.js';
import { exportSetCSV, exportSetXLSX } from './utils/export.js';
import { norm } from './utils/search.js';
import './index.css';

// ── Persist custom sets ────────────────────────────────────────────
function loadCustomSets() {
  try { return JSON.parse(localStorage.getItem('ah_customSets') || '[]'); } catch { return []; }
}
function saveCustomSets(sets) {
  try { localStorage.setItem('ah_customSets', JSON.stringify(sets)); } catch {}
}

export default function App() {
  const [page,        setPage]        = useState('dashboard'); // 'dashboard' | 'view' | 'create'
  const [customSets,  setCustomSets]  = useState(loadCustomSets);
  const [currentSet,  setCurrentSet]  = useState(null);
  const [createName,  setCreateName]  = useState('');
  const [createAttrs, setCreateAttrs] = useState([]);
  const [aiLoading,   setAiLoading]   = useState(false);
  const [aiError,     setAiError]     = useState('');
  const [apiKey,      setApiKey]      = useState(() => {
    try { return sessionStorage.getItem('ah_api_key') || ''; } catch { return ''; }
  });

  useEffect(() => {
    try { sessionStorage.setItem('ah_api_key', apiKey); } catch {}
  }, [apiKey]);

  function updateCustomSets(sets) {
    setCustomSets(sets);
    saveCustomSets(sets);
  }

  function openSet(set) {
    setCurrentSet(set);
    setPage('view');
  }

  function goCreate(prefillName = '') {
    setCreateName(prefillName);
    setCreateAttrs([]);
    setAiError('');
    setPage('create');
  }

  async function runAIGenerate() {
    if (!createName.trim()) return;
    setAiLoading(true);
    setAiError('');
    try {
      const result = await generateAttributes(createName, apiKey);
      setCreateAttrs((result.attributes || []).map(norm));
    } catch (err) {
      setAiError(err.message);
    }
    setAiLoading(false);
  }

  function saveToMaster() {
    if (!createAttrs.length) return;
    const newSet = {
      id: `custom-${Date.now()}`,
      categoryName: createName,
      className: createName,
      metaCategory: 'Custom',
      description: `Custom set for ${createName}`,
      attributes: createAttrs,
      lastUpdated: new Date().toISOString().slice(0, 10),
      version: '1.0',
    };
    updateCustomSets([...customSets, newSet]);
    alert(`"${createName}" saved to master DB!`);
    setPage('dashboard');
  }

  const stats = {
    total: allSets(customSets).length,
    custom: customSets.length,
    batches: (() => { try { return JSON.parse(localStorage.getItem('ah_batchHistory') || '[]').length; } catch { return 0; } })(),
  };

  // ── Render ───────────────────────────────────────────────────────
  return (
    <div className="app">
      <Topbar
        apiKey={apiKey}
        onApiKeyChange={setApiKey}
        showBack={page !== 'dashboard'}
        onBack={() => setPage('dashboard')}
      />

      <div className="main">
        {/* ── Dashboard ──────────────────────────────────────────── */}
        {page === 'dashboard' && (
          <Dashboard
            customSets={customSets}
            apiKey={apiKey}
            onOpenSet={openSet}
            onGoCreate={goCreate}
            stats={stats}
          />
        )}

        {/* ── View Set ───────────────────────────────────────────── */}
        {page === 'view' && currentSet && (
          <div className="page">
            <div className="pg-head">
              <div className="pg-icon"><i className="ti ti-tag" /></div>
              <div style={{ flex: 1 }}>
                <div className="pg-title">{currentSet.categoryName}</div>
                <div className="pg-sub">{currentSet.description}</div>
              </div>
              <div style={{ display: 'flex', gap: 8 }}>
                <button className="btn btn-sm" onClick={() => exportSetCSV(currentSet)}>
                  <i className="ti ti-file-text" /> CSV
                </button>
                <button className="btn btn-sm btn-primary" onClick={() => exportSetXLSX(currentSet)}>
                  <i className="ti ti-file-spreadsheet" /> Excel
                </button>
                <button className="btn btn-sm btn-primary" onClick={() => goCreate(currentSet.categoryName)}>
                  <i className="ti ti-sparkles" /> Regenerate with AI
                </button>
              </div>
            </div>
            <AttributeTable attributes={currentSet.attributes} showActions={false} />
          </div>
        )}

        {/* ── Create / AI Generate ───────────────────────────────── */}
        {page === 'create' && (
          <div className="page">
            <div className="pg-head">
              <div className="pg-icon"><i className="ti ti-sparkles" /></div>
              <div style={{ flex: 1 }}>
                <div className="pg-title">Generate Attribute Set</div>
                <div className="pg-sub">AI-powered attribute generation via OpenRouter</div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: 10, marginBottom: 20, alignItems: 'flex-end' }}>
              <div style={{ flex: 1 }}>
                <label className="field-lbl">Category Name</label>
                <input
                  className="search-input"
                  placeholder="e.g. Running Shoes, OLED TVs…"
                  value={createName}
                  onChange={e => setCreateName(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && runAIGenerate()}
                />
              </div>
              <button className="btn btn-primary" onClick={runAIGenerate} disabled={aiLoading || !createName.trim()}>
                {aiLoading
                  ? <><i className="ti ti-loader-2 spinning" /> Generating…</>
                  : <><i className="ti ti-sparkles" /> Generate</>
                }
              </button>
            </div>

            {aiError && (
              <div style={{ background: 'var(--red-bg)', border: '1px solid var(--red-border)', borderRadius: 8, padding: '12px 16px', marginBottom: 16, color: 'var(--red)', fontSize: 13 }}>
                <i className="ti ti-alert-circle" /> {aiError}
              </div>
            )}

            {createAttrs.length > 0 && (
              <>
                <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
                  <button className="btn btn-sm" onClick={() => exportSetCSV({ categoryName: createName, attributes: createAttrs })}>
                    <i className="ti ti-file-text" /> Export CSV
                  </button>
                  <button className="btn btn-sm" onClick={() => exportSetXLSX({ categoryName: createName, attributes: createAttrs })}>
                    <i className="ti ti-file-spreadsheet" /> Export Excel
                  </button>
                  <button className="btn btn-primary btn-sm" onClick={saveToMaster}>
                    <i className="ti ti-device-floppy" /> Save to Master DB
                  </button>
                </div>
                <AttributeTable
                  attributes={createAttrs}
                  onDelete={i => setCreateAttrs(prev => prev.filter((_, j) => j !== i))}
                />
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

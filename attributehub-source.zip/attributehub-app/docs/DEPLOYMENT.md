# Deployment Guide — AttributeHub

## Prerequisites
- Node.js 18+ and npm 9+
- An OpenRouter API key (https://openrouter.ai)

## Local Development

    git clone <repo-url>
    cd attributehub-app
    cp .env.example .env        # add OPENROUTER_API_KEY
    npm run install:all
    npm run dev                 # frontend :5173, backend :3001

## Production Build

    npm run build               # builds frontend to frontend/dist/
    npm run start               # backend serves frontend/dist/

## Railway (recommended one-click)
1. Push to GitHub
2. New Project -> Deploy from GitHub
3. Add env var: OPENROUTER_API_KEY
4. Build: npm run install:all && npm run build
5. Start: npm run start

## Docker

    docker build -t attributehub .
    docker run -p 3001:3001 -e OPENROUTER_API_KEY=sk-or-v1-... attributehub

## Environment Variables
| Variable              | Required     | Description                         |
|-----------------------|-------------|-------------------------------------|
| OPENROUTER_API_KEY    | Recommended | Server-side AI key                  |
| PORT                  | No          | Backend port (default 3001)         |
| NODE_ENV              | In prod     | Set to production                   |
| VITE_API_BASE         | Frontend    | Backend URL when deployed separately|

/**
 * AI prompt builders for AttributeHub
 * Centralise all prompts here for easy tuning.
 */

const ATTR_SCHEMA = `
Each attribute must be a JSON object with these exact keys:
{
  "name": "string",
  "requirement": "Mandatory" | "Recommended" | "Optional",
  "possibleValues": ["string"],
  "unit": "string",
  "type": "text" | "single_select" | "multi_select" | "number",
  "dataType": "LOV" | "Numeric" | "Integer" | "Text",
  "attributeType": "Product" | "Variant" | "Item",
  "uom": "string",
  "multiSelect": "Y" | "N",
  "isFrontendNode": "Y" | "N",
  "isDependent": "Y" | "N",
  "dependentOn": "string",
  "competitorCoverage": 0-100,
  "gs1Required": true | false,
  "trendSignal": "rising" | "stable" | "declining",
  "rationale": "string"
}`.trim();

function buildGeneratePrompt(categoryName) {
  return `Return ONLY a valid JSON array. No markdown. No explanation. Start with [ and end with ].

Category: "${categoryName}"

Generate 10-14 product attributes SPECIFIC and RELEVANT to the "${categoryName}" category.
Do NOT include generic attributes like "Display Name", "Country of Origin" unless genuinely critical.
Focus on physical specs, performance characteristics, and buyer-decision attributes for this category.

Rules:
- requirement = Mandatory if competitorCoverage >= 90 or gs1Required or legally required; else Recommended
- dataType = Numeric or Integer for measurements; LOV for enumerations; Text for free-form
- type = number when dataType is Numeric or Integer
- Include realistic possibleValues for LOV types (4-8 values)
- Include appropriate units/uom for numeric attributes
- isFrontendNode = Y for filterable/searchable attributes shown to shoppers
- trendSignal = rising for attributes growing in importance (sustainability, AI-features, etc.)

${ATTR_SCHEMA}`;
}

function buildRefreshPrompt(categoryName, existingAttributes) {
  const existingNames = existingAttributes.map(a => a.name || a.n || '').filter(Boolean).join(', ');
  return `Return ONLY a valid JSON array. No markdown. No explanation. Start with [ and end with ].

Category: "${categoryName}"
Existing attributes to improve upon: ${existingNames || 'none'}

Refresh and improve this attribute set. Keep the strongest existing attributes, remove generic ones,
and ADD any missing high-value attributes specific to "${categoryName}".
Target 12-15 total attributes. Prioritise attributes rising in importance (sustainability, connectivity, smart features).

${ATTR_SCHEMA}`;
}

module.exports = { buildGeneratePrompt, buildRefreshPrompt };

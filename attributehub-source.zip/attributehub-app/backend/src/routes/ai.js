const express   = require('express');
const rateLimit = require('express-rate-limit');
const fetch     = require('node-fetch');
const { buildGeneratePrompt, buildRefreshPrompt } = require('../utils/prompts');

const router = express.Router();

const limiter = rateLimit({
  windowMs: 60 * 1000,   // 1 minute
  max: 30,
  message: { error: 'Too many requests — slow down.' },
});
router.use(limiter);

// Resolve API key: prefer server env, fall back to client-supplied header
function resolveKey(req) {
  return process.env.OPENROUTER_API_KEY || req.headers['x-api-key'] || '';
}

const MODELS = [
  'openai/gpt-4o-mini',
  'anthropic/claude-3-haiku',
  'anthropic/claude-3.5-haiku',
  'google/gemini-1.5-flash',
  'mistralai/mistral-7b-instruct',
];

const ENDPOINT = 'https://openrouter.ai/api/v1/chat/completions';

async function callAI(apiKey, prompt) {
  let lastErr = '';
  for (const model of MODELS) {
    const res = await fetch(ENDPOINT, {
      method: 'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'HTTP-Referer':  'https://attributehub.ecomneo.com',
        'X-Title':       'AttributeHub',
      },
      body: JSON.stringify({ model, max_tokens: 2000, messages: [{ role: 'user', content: prompt }] }),
    });

    const data = await res.json();
    if (res.ok) {
      const text = data.choices?.[0]?.message?.content || '';
      return { text, model };
    }

    lastErr = data?.error?.message || `HTTP ${res.status}`;
    const isModelErr = lastErr.toLowerCase().includes('endpoint')
      || lastErr.toLowerCase().includes('no endpoints')
      || lastErr.toLowerCase().includes('not found');
    if (!isModelErr) break;
  }
  throw new Error(lastErr || 'All models failed');
}

function parseAttrs(text) {
  let clean = text
    .replace(/```json[\s\S]*?```/gi, m => m.replace(/```json/i, '').replace(/```/g, ''))
    .replace(/```[\s\S]*?```/g, m => m.replace(/```/g, ''))
    .trim();
  const start = clean.indexOf('[');
  const end   = clean.lastIndexOf(']');
  if (start === -1 || end === -1) throw new Error('No JSON array in response');
  return JSON.parse(clean.slice(start, end + 1));
}

// POST /api/ai/generate
router.post('/generate', async (req, res) => {
  const { categoryName } = req.body;
  if (!categoryName) return res.status(400).json({ error: 'categoryName required' });

  const apiKey = resolveKey(req);
  if (!apiKey) return res.status(401).json({ error: 'No API key available. Set OPENROUTER_API_KEY or send x-api-key header.' });

  try {
    const prompt = buildGeneratePrompt(categoryName);
    const { text, model } = await callAI(apiKey, prompt);
    const attrs = parseAttrs(text);
    res.json({ attributes: attrs, model });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

// POST /api/ai/refresh
router.post('/refresh', async (req, res) => {
  const { categoryName, existingAttributes } = req.body;
  if (!categoryName) return res.status(400).json({ error: 'categoryName required' });

  const apiKey = resolveKey(req);
  if (!apiKey) return res.status(401).json({ error: 'No API key available.' });

  try {
    const prompt = buildRefreshPrompt(categoryName, existingAttributes || []);
    const { text, model } = await callAI(apiKey, prompt);
    const attrs = parseAttrs(text);
    res.json({ attributes: attrs, model });
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

module.exports = router;

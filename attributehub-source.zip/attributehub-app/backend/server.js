require('dotenv').config({ path: '../.env' });
const express  = require('express');
const cors     = require('cors');
const path     = require('path');
const aiRoutes = require('./src/routes/ai');

const app  = express();
const PORT = process.env.PORT || 3001;
const isProd = process.env.NODE_ENV === 'production';

// ── Middleware ────────────────────────────────────────────────────
app.use(cors({
  origin: isProd ? false : ['http://localhost:5173', 'http://127.0.0.1:5173'],
  methods: ['GET', 'POST'],
  allowedHeaders: ['Content-Type', 'x-api-key'],
}));
app.use(express.json({ limit: '2mb' }));

// ── API Routes ────────────────────────────────────────────────────
app.use('/api/ai', aiRoutes);

app.get('/api/health', (_req, res) => res.json({ ok: true, ts: Date.now() }));

// ── Serve frontend in production ──────────────────────────────────
if (isProd) {
  const distPath = path.join(__dirname, '../frontend/dist');
  app.use(express.static(distPath));
  app.get('*', (_req, res) => res.sendFile(path.join(distPath, 'index.html')));
}

app.listen(PORT, () => {
  console.log(`AttributeHub backend running on http://localhost:${PORT}`);
  if (!process.env.OPENROUTER_API_KEY) {
    console.warn('⚠  OPENROUTER_API_KEY not set — AI routes will use the client-supplied key.');
  }
});
